import UIKit
import WebKit
import AVFoundation

final class GameViewController: UIViewController {

    private var webView: WKWebView!

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.039, green: 0.031, blue: 0.024, alpha: 1)

        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        config.preferences.javaScriptEnabled = true
        config.preferences.setValue(true, forKey: "allowFileAccessFromFileURLs")
        config.preferences.setValue(true, forKey: "allowUniversalAccessFromFileURLs")
        if #available(iOS 14.0, *) {
            config.defaultWebpagePreferences.allowsContentJavaScript = true
        }

        let unlock = """
        (function () {
          var instances = [];
          function track(ctx) {
            if (!ctx) return;
            instances.push(ctx);
            try {
              if (ctx.addEventListener) {
                ctx.addEventListener('statechange', function () {
                  if (ctx.state === 'suspended') { try { ctx.resume(); } catch (e) {} }
                });
              }
            } catch (e) {}
          }
          var AC = window.AudioContext || window.webkitAudioContext;
          if (AC) {
            function Patched() {
              var ctx = new AC();
              track(ctx);
              try { if (ctx.state === 'suspended') ctx.resume(); } catch (e) {}
              return ctx;
            }
            Patched.prototype = AC.prototype;
            window.AudioContext = Patched;
            window.webkitAudioContext = Patched;
          }
          function unlock() {
            for (var i = 0; i < instances.length; i++) {
              var c = instances[i];
              try { if (c.state === 'suspended') c.resume(); } catch (e) {}
            }
          }
          window.__unlockAudio = unlock;
          var evs = ['touchstart', 'touchend', 'pointerdown', 'pointerup', 'mousedown', 'mouseup', 'click', 'keydown'];
          evs.forEach(function (ev) {
            window.addEventListener(ev, unlock, { capture: true, passive: true });
          });
          var booted = false;
          function boot() {
            if (booted) return; booted = true;
            try {
              var a = document.createElement('audio');
              a.preload = 'auto'; a.loop = true; a.muted = true;
              a.setAttribute('x-webkit-airplay', 'deny');
              var p = a.play();
              if (p && p.catch) p.catch(function () {});
            } catch (e) {}
          }
          ['touchstart', 'pointerdown', 'mousedown', 'click'].forEach(function (ev) {
            window.addEventListener(ev, boot, { capture: true, passive: true });
          });
        })();
        """
        config.userContentController.addUserScript(WKUserScript(source: unlock, injectionTime: .atDocumentStart, forMainFrameOnly: false))

        let web = WKWebView(frame: .zero, configuration: config)
        web.isOpaque = false
        web.backgroundColor = .clear
        web.scrollView.isScrollEnabled = false
        web.scrollView.bounces = false
        web.scrollView.showsVerticalScrollIndicator = false
        web.scrollView.showsHorizontalScrollIndicator = false
        web.scrollView.contentInsetAdjustmentBehavior = .never
        web.allowsBackForwardNavigationGestures = false
        web.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(web)

        NSLayoutConstraint.activate([
            web.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            web.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            web.topAnchor.constraint(equalTo: view.topAnchor),
            web.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        webView = web
        loadGame()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        try? AVAudioSession.sharedInstance().setActive(true)
    }

    private func loadGame() {
        guard let url = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "game") else {
            return
        }
        webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
    }

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .portrait }
    override var shouldAutorotate: Bool { false }
    override var preferredScreenEdgesDeferringSystemGestures: UIRectEdge { .bottom }
}
