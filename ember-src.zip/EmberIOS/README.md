# 余烬 · 十分钟 — iOS 原生外壳工程

这个工程把网页版游戏原封不动装进 WKWebView，编译出来就是能装进 iPhone 的 App（ipa）。
游戏本体在 `Ember/game/index.html`，单文件、离线可玩，改完直接重新编译即可，不需要重新上传网页。

## 为什么不能在这里直接出 ipa

ipa 只能由 **macOS + Xcode** 编译和签名（iOS 的编译链、签名、描述文件都在苹果那侧）。
Windows 上没有可用的 iOS 工具链，任何声称在 Windows 生成的 ipa 都装不进手机。
所以这里交付的是**完整可直接编译的工程 + 一条命令出包的脚本**，你在 Mac（或云 Mac）上跑一次就有 ipa。

## 出 ipa 的两种方式

### 方式一：命令行（适合云 Mac / 远程机器）

```bash
cd 余烬iOS
chmod +x build-ipa.sh
TEAM_ID=你的团队ID BUNDLE_ID=com.yourname.ember ./build-ipa.sh
```

产物在 `build/ipa/Ember.ipa`。
`TEAM_ID` 在 Xcode 的 Signing & Capabilities 或在 developer.apple.com 的 Membership 页面能查到。

### 方式二：Xcode 图形界面

1. 双击 `Ember.xcodeproj` 打开。
2. 选中左侧 Ember 工程 → Signing & Capabilities：
   - Team 选你自己的开发者账号；
   - Bundle Identifier 改成你自己的，比如 `com.qu.ember`（不能和别人重复）。
3. 顶部设备选你自己的 iPhone，点运行，即可直接装到手机（首次要在 设置 → 通用 → VPN与设备管理 里信任开发者）。
4. 想要 ipa 文件：菜单 Product → Archive，结束后在 Organizer 点 Distribute App → Development → Export，导出目录里就是 ipa。

## 已做的 iOS 侧适配

- `AVAudioSession` 设为 `.playback`，**侧边静音键不会静音游戏声音**，锁屏切走会自动停音。
- 关闭滚动、回弹、缩放、下拉刷新，全屏无状态栏，竖屏锁定，关闭底部小横条自动隐藏延迟。
- 页面资源全部本地加载，断网可玩，不请求任何外部依赖。
- 1024 图标已按单尺寸 AppIcon 规范放好。

## 目录

```
余烬iOS/
  Ember.xcodeproj/            工程文件（含共享 scheme）
  Ember/
    AppDelegate.swift         启动、音频会话
    GameViewController.swift  WKWebView 容器、本地加载、全屏约束
    Info.plist
    Assets.xcassets/          1024 图标
    game/index.html           游戏本体
  build-ipa.sh                一条命令出 ipa
```

## 装到 iPhone 6s

iPhone 6s 最高 iOS 15，本工程最低版本 12，直接支持。
自签名 ipa 可以用 Sideloadly / AltStore 装（需要你自己的 Apple ID），或者用 Xcode 直接连数据线运行。
苹果账号登录、证书、设备登记这些必须由你本人操作。
