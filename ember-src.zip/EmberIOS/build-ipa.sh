#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

TEAM_ID="${TEAM_ID:-}"
BUNDLE_ID="${BUNDLE_ID:-com.ember.tenminutes}"
SCHEME="Ember"
OUT="build"

if [ -z "$TEAM_ID" ]; then
  echo "缺少 TEAM_ID。用法：TEAM_ID=你的10位团队ID BUNDLE_ID=com.yourname.ember ./build-ipa.sh"
  echo "团队 ID 在 Xcode 的 Signing & Capabilities 里，或 developer.apple.com 的 Membership 页。"
  exit 1
fi

rm -rf "$OUT"
mkdir -p "$OUT"

xcodebuild \
  -project Ember.xcodeproj \
  -scheme "$SCHEME" \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -archivePath "$OUT/Ember.xcarchive" \
  -allowProvisioningUpdates \
  DEVELOPMENT_TEAM="$TEAM_ID" \
  PRODUCT_BUNDLE_IDENTIFIER="$BUNDLE_ID" \
  CODE_SIGN_STYLE=Automatic \
  archive

cat > "$OUT/ExportOptions.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>method</key>
    <string>development</string>
    <key>teamID</key>
    <string>${TEAM_ID}</string>
    <key>signingStyle</key>
    <string>automatic</string>
    <key>stripSwiftSymbols</key>
    <true/>
    <key>compileBitcode</key>
    <false/>
    <key>destination</key>
    <string>export</string>
</dict>
</plist>
PLIST

xcodebuild \
  -exportArchive \
  -archivePath "$OUT/Ember.xcarchive" \
  -exportPath "$OUT/ipa" \
  -exportOptionsPlist "$OUT/ExportOptions.plist" \
  -allowProvisioningUpdates

echo ""
echo "完成："
ls -lh "$OUT/ipa"
